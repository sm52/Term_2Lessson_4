import java.io. *;
import static java.lang.System. *;

public class Vehicle {
  private int location;

  public Vehicle(){
    location = 0;
  }

  public Vehicle(int loc){
    if((loc>=-20)||(loc<=20)){
      location = 0;
    }
    location = loc;
  }

  public void forward(){
    location ++;
    if (location > 20){
      location = 20;
    }
  }

  public void backward(){
    location --;
    if (location < -20){
      location = -20;
    }
  }

  public int getLocation(){
    return location;
  }

  public String toString(){
    String spaces = new String();
    int spot  = 20 + location;
    for (int i = 0; i < spot; i ++){
      spaces += " ";
    }
    spaces += "@";
    return spaces;
  }
}